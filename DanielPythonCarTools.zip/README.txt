Defender, and malware bytes will say this is a trojan.
It is not. However, given the cryptographic algorithms inside for things like AES cluster patching, radar patch, etc, and that it phones home for an update check, it get's flagged.

It is possible to run this in a VM just fine, so if you're worried about it, run it there.